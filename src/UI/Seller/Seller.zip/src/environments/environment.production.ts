export const environment = {
  production: true,
  clientID: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx',
  buyerID: 'xxxxxxxxxx',
  buyerClientID: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx',
  buyerUrl: '',
  middlewareUrl: 'my-middleware-url.com/api',
};
