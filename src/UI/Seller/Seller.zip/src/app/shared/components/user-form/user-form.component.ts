import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  Inject,
  ComponentFactoryResolver,
} from '@angular/core';
import { OcUserService, User } from '@ordercloud/angular-sdk';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AppFormErrorService } from '@app-seller/shared/services/form-error/form-error.service';
import { RegexService } from '@app-seller/shared/services/regex/regex.service';
import { Router } from '@angular/router';
import {
  applicationConfiguration,
  AppConfig,
} from '@app-seller/config/app.config';
import { ModalService } from '@app-seller/shared/services/modal/modal.service';
import { ToastrService } from 'ngx-toastr';
import { faUser } from '@fortawesome/free-solid-svg-icons';
@Component({
  selector: 'user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.scss'],
})
export class UserFormComponent implements OnInit {
  protected _existingUser: User = {};
  @Input()
  btnText: string;
  @Output()
  formSubmitted = new EventEmitter<{ user: User; prevID: string }>();
  userForm: FormGroup;
  router: any;
  confirmationModalId = 'confirmationModalapprove';
  faUser = faUser;

  formValue: any;

  constructor(
    private formBuilder: FormBuilder,
    private formErrorService: AppFormErrorService,
    private regexService: RegexService,
    private ocUserService: OcUserService,
    private _router: Router,
    private toastrService: ToastrService,
    private modalService: ModalService,
    @Inject(applicationConfiguration) private appConfig: AppConfig
  ) {
    this.router = _router.url;
  }

  ngOnInit() {
    this.setForm();
  }

  @Input()
  set existingUser(user: User) {
    this._existingUser = user || {};
    // console.log(this._existingUser)
    if (!this.userForm) {
      this.setForm();
      return;
    }

    this.userForm.setValue({
      ID: this._existingUser.ID || '',
      Username: this._existingUser.Username || '',
      FirstName: this._existingUser.FirstName || '',
      LastName: this._existingUser.LastName || '',
      Phone: this._existingUser.Phone || '',
      Email: this._existingUser.Email || '',
      Active: !!this._existingUser.Active,

      City:
        (this._existingUser &&
          this._existingUser.xp &&
          this._existingUser.xp.City) ||
        '',
      ZipCode:
        (this._existingUser &&
          this._existingUser.xp &&
          this._existingUser.xp.ZipCode) ||
        '',
    });
    // console.log(this._existingUser)
  }

  setForm() {
    this.userForm = this.formBuilder.group({
      ID: [
        this._existingUser.ID || '',
        Validators.pattern(this.regexService.ID),
      ],
      Username: [this._existingUser.Username || '', Validators.required],
      FirstName: [
        this._existingUser.FirstName || '',
        [Validators.required, Validators.pattern(this.regexService.HumanName)],
      ],
      LastName: [
        this._existingUser.LastName || '',
        [Validators.required, Validators.pattern(this.regexService.HumanName)],
      ],
      Phone: [
        this._existingUser.Phone || '',
        Validators.pattern(this.regexService.Phone),
      ],
      Email: [
        this._existingUser.Email || '',
        [Validators.required, Validators.email],
      ],
      Active: [!!this._existingUser.Active],

      City: [
        (this._existingUser &&
          this._existingUser.xp &&
          this._existingUser.xp.City) ||
          '',
        [Validators.required, Validators.pattern(this.regexService.City)],
      ],
      ZipCode: [
        (this._existingUser &&
          this._existingUser.xp &&
          this._existingUser.xp.ZipCode) ||
          '',
        [Validators.required, Validators.pattern(this.regexService.ZipCode)],
      ],
    });
  }
  b: number = 10;

  openConfirmationDialog = () => {
    this.modalService.open(this.confirmationModalId);

    this.formValue = new Object();
    //this.formValue = JSON.stringify({...this.userForm.value})
    this.formValue = this.userForm.value;
    //debugger;
    this.sendData();
  };
  closeConfirmDialog() {
    this.modalService.close(this.confirmationModalId);
  }

  sendData() {
    console.log('from send data', this.formValue);
  }
  getFormData = () => {
    //this.formValue = this.userForm.value;
    ///console.log(this.userForm.value);
    console.log('from get data', this.formValue);
  };

  protected onSubmit() {
    console.log('submit1');
    console.log(this.userForm.value);

    if (this.userForm.status === 'INVALID') {
      console.log('submit2');
      // this.modalService.close(this.confirmationModalId)
      return this.formErrorService.displayFormErrors(this.userForm);
    }

    let userInfo = {
      Active: this.userForm.value.Active,
      Email: this.userForm.value.Email,
      FirstName: this.userForm.value.FirstName,
      ID: this.userForm.value.ID,
      LastName: this.userForm.value.LastName,
      Phone: this.userForm.value.Phone,
      Username: this.userForm.value.Username,
      xp: {
        City: this.userForm.value.City,
        ZipCode: this.userForm.value.ZipCode,
        isApproved: true,
      },
    };

    console.log(userInfo);
    this.formSubmitted.emit({
      user: userInfo,
      prevID: this._existingUser.ID,
    });
    this.modalService.close(this.confirmationModalId);
    this.toastrService.success('User Approved succesfully ');
    console.log('submit3');
  }

  // control display of error messages
  protected hasRequiredError = (controlName: string) =>
    this.formErrorService.hasRequiredError(controlName, this.userForm);
  protected hasPatternError = (controlName: string) =>
    this.formErrorService.hasPatternError(controlName, this.userForm);
  protected hasEmailError = () =>
    this.formErrorService.hasValidEmailError(this.userForm.get('Email'));
}
